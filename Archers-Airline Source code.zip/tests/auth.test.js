const request = require('supertest');
const app = require('../server'); // Import the Express app
const User = require('../models/User');

let agent; 
let csrfToken;

async function refreshCsrfToken() {
    const response = await agent.get('/');
    const match = response.text.match(/<meta name="csrf-token" content="([^"]+)"/);
    if (!match) throw new Error('CSRF token was not rendered.');
    csrfToken = match[1];
}

describe('Authentication Tests', () => {

    beforeAll(async () => {
        agent = request.agent(app);
    });

    beforeEach(async () => {
        await refreshCsrfToken();
    });

    afterEach(async () => {
        await agent.post('/users/logout').set('x-csrf-token', csrfToken);
    });

    // Registration test
    describe('POST /users/register', () => {
        // valid registration test
        it('User Registration - Valid', async () => {
            const res = await agent
                .post('/users/register')
                .set('x-csrf-token', csrfToken)
                .send({
                    firstName: 'Test',
                    lastName: 'User',
                    email: 'test@example.com',
                    password: 'password123',
                    isAdult: true,
                    privacyNoticeAccepted: true
                });
            expect(res.statusCode).toEqual(200);
            expect(res.body).toHaveProperty('success', true)
        });

        // invalid registration test
        it('User Registration - Duplicate Email', async () => {
            // create user first
            await agent
                .post('/users/register')
                .set('x-csrf-token', csrfToken)
                .send({
                    firstName: 'Duplicate',
                    lastName: 'User',
                    email: 'duplicate@test.com',
                    password: 'password123',
                    isAdult: true,
                    privacyNoticeAccepted: true
                });

            // Try to create the same user again
            const res = await agent 
                .post('/users/register')
                .set('x-csrf-token', csrfToken)
                .send({
                    firstName: 'Dup',
                    lastName: 'User',
                    email: 'duplicate@test.com', // duplicate email
                    password: 'password123',
                    isAdult: true,
                    privacyNoticeAccepted: true
                });

            expect(res.statusCode).toEqual(400);   
            expect(res.body).toHaveProperty('success', false);
            expect(res.body.message).toBe('Email already registered');
        });

    });
    

    // user login test
    describe('POST /users/login', () => {
        // create a user before each test
        beforeEach(async () => {
             //create a user and login
             const resUser = new User({
                firstName: 'Test',
                lastName: 'User',
                email: 'test@example.com',
                password: 'password123',
                dateOfBirth: new Date()
            });
            await resUser.save();
        });

        // valid login test
        it('should login successfully with correct credentials', async () => {
            const res = await agent
                .post('/users/login')
                .set('x-csrf-token', csrfToken)
                .send({ 
                    email: 'test@example.com',
                    password: 'password123'
                });
            
            expect(res.statusCode).toEqual(200);
            expect(res.body).toHaveProperty('success', true);
            expect(res.body.message).toBe('Welcome, Test!');
            await refreshCsrfToken();
        });
    
        // invalid login test with unregistered
        it('should fail login with incorrect credentials', async () => {
            const res = await agent
                .post('/users/login')
                .set('x-csrf-token', csrfToken)
                .send({ 
                    email: 'wrong@example.com', 
                    password: 'wrongpass' 
                });
            expect(res.statusCode).toEqual(401);
            expect(res.body.message).toBe('Invalid email or password.');
        });

        // invalid login test with wrong password
        it('should fail login with incorrect password', async () => {
            const res = await agent
                .post('/users/login')
                .set('x-csrf-token', csrfToken)
                .send({ 
                    email: 'test@example.com', 
                    password: 'wrongpass' 
                });
            expect(res.statusCode).toEqual(401);
            expect(res.body.message).toBe('Invalid email or password.');
        });
    });

    // Accessing routes that require login
    describe('GET /users/profile', () => {
        it('should prevent access to this page', async () => {
            const res = await agent 
                .get('/users/profile');

            expect(res.statusCode).toEqual(403);
            expect(res.text).toMatch(/<title>Access Denied<\/title>/);
        });
    });

    // Test for logout
    describe('POST /users/logout', () => {
        it('should successfully logout a user', async () => {
            //create a user and login
            const resUser = new User({
                firstName: 'Test',
                lastName: 'User',
                email: 'test@example.com',
                password: 'password123',
                dateOfBirth: new Date()
            });
            await resUser.save();

            // login user
            const resLogin = await agent
            .post('/users/login')
            .set('x-csrf-token', csrfToken)
            .send({ 
                email: 'test@example.com',
                password: 'password123'
            });
            await refreshCsrfToken();

            // logout user
            const res = await agent
                .post('/users/logout')
                .set('x-csrf-token', csrfToken);

            expect(res.statusCode).toEqual(200);
            expect(res.body).toHaveProperty('success', true);
        });
    });

});
